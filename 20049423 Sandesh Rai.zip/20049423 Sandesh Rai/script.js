//creating a function
function validate() {
  var first_name = document.forms["messageForms"]["first_name"].value;  //bringing document data of firstname and writing form name and field name.
  var last_name = document.forms["messageForms"]["last_name"].value;    //bringing document data of lastname and writing form name and field name.
  var message = document.forms["messageForms"]["message"].value;        //bringing document data of message and writing form name and field name.

  if (first_name == "" || last_name == "" || message == "") {       //condition check
    alert("Sorry! The field is empty");     
  } else {
    alert("Thank you!");
  }

  